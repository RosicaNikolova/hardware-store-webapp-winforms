﻿
namespace MediaBazaarProject
{
    partial class createEmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txbBsn = new System.Windows.Forms.TextBox();
            this.txbFirstName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.cbPosition = new System.Windows.Forms.ComboBox();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.txbLastName = new System.Windows.Forms.TextBox();
            this.txbEmail = new System.Windows.Forms.TextBox();
            this.txbPassword = new System.Windows.Forms.TextBox();
            this.txbAddress = new System.Windows.Forms.TextBox();
            this.txbPhone = new System.Windows.Forms.TextBox();
            this.txbHourlyWage = new System.Windows.Forms.TextBox();
            this.btnUpdateEmployee = new System.Windows.Forms.Button();
            this.lblCovidVaccinated = new System.Windows.Forms.Label();
            this.rBtnYes = new System.Windows.Forms.RadioButton();
            this.rBtnNo = new System.Windows.Forms.RadioButton();
            this.lblIsAccountActive = new System.Windows.Forms.Label();
            this.rBtnActive = new System.Windows.Forms.RadioButton();
            this.rBtnNotActive = new System.Windows.Forms.RadioButton();
            this.lblAge = new System.Windows.Forms.Label();
            this.tbAge = new System.Windows.Forms.TextBox();
            this.lblNationality = new System.Windows.Forms.Label();
            this.cbNationality = new System.Windows.Forms.ComboBox();
            this.rBtnYesPermanent = new System.Windows.Forms.RadioButton();
            this.rBtnNotPermanent = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.rBtnMale = new System.Windows.Forms.RadioButton();
            this.rBtnFemale = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "BSN:";
            // 
            // txbBsn
            // 
            this.txbBsn.Location = new System.Drawing.Point(168, 37);
            this.txbBsn.Name = "txbBsn";
            this.txbBsn.Size = new System.Drawing.Size(112, 27);
            this.txbBsn.TabIndex = 1;
            // 
            // txbFirstName
            // 
            this.txbFirstName.Location = new System.Drawing.Point(168, 81);
            this.txbFirstName.Name = "txbFirstName";
            this.txbFirstName.Size = new System.Drawing.Size(112, 27);
            this.txbFirstName.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "First Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Last Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "E-mail:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 218);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Password:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Permanent Contract:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 334);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "Address:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 376);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = "Phone number:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 417);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 20);
            this.label9.TabIndex = 10;
            this.label9.Text = "Hourly wage:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(33, 462);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 20);
            this.label10.TabIndex = 11;
            this.label10.Text = "Position:";
            // 
            // cbPosition
            // 
            this.cbPosition.FormattingEnabled = true;
            this.cbPosition.Items.AddRange(new object[] {
            "Admin",
            "Manager",
            "Sales",
            "Warehouse"});
            this.cbPosition.Location = new System.Drawing.Point(168, 459);
            this.cbPosition.Name = "cbPosition";
            this.cbPosition.Size = new System.Drawing.Size(151, 28);
            this.cbPosition.TabIndex = 12;
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.Location = new System.Drawing.Point(604, 497);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(181, 54);
            this.btnAddEmployee.TabIndex = 13;
            this.btnAddEmployee.Text = "Add Employee";
            this.btnAddEmployee.UseVisualStyleBackColor = true;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // txbLastName
            // 
            this.txbLastName.Location = new System.Drawing.Point(168, 125);
            this.txbLastName.Name = "txbLastName";
            this.txbLastName.Size = new System.Drawing.Size(112, 27);
            this.txbLastName.TabIndex = 14;
            // 
            // txbEmail
            // 
            this.txbEmail.Location = new System.Drawing.Point(168, 169);
            this.txbEmail.Name = "txbEmail";
            this.txbEmail.Size = new System.Drawing.Size(112, 27);
            this.txbEmail.TabIndex = 15;
            // 
            // txbPassword
            // 
            this.txbPassword.Location = new System.Drawing.Point(168, 211);
            this.txbPassword.Name = "txbPassword";
            this.txbPassword.Size = new System.Drawing.Size(112, 27);
            this.txbPassword.TabIndex = 16;
            // 
            // txbAddress
            // 
            this.txbAddress.Location = new System.Drawing.Point(168, 328);
            this.txbAddress.Name = "txbAddress";
            this.txbAddress.Size = new System.Drawing.Size(112, 27);
            this.txbAddress.TabIndex = 17;
            // 
            // txbPhone
            // 
            this.txbPhone.Location = new System.Drawing.Point(168, 371);
            this.txbPhone.Name = "txbPhone";
            this.txbPhone.Size = new System.Drawing.Size(112, 27);
            this.txbPhone.TabIndex = 18;
            // 
            // txbHourlyWage
            // 
            this.txbHourlyWage.Location = new System.Drawing.Point(168, 417);
            this.txbHourlyWage.Name = "txbHourlyWage";
            this.txbHourlyWage.Size = new System.Drawing.Size(112, 27);
            this.txbHourlyWage.TabIndex = 19;
            // 
            // btnUpdateEmployee
            // 
            this.btnUpdateEmployee.Location = new System.Drawing.Point(407, 497);
            this.btnUpdateEmployee.Name = "btnUpdateEmployee";
            this.btnUpdateEmployee.Size = new System.Drawing.Size(181, 54);
            this.btnUpdateEmployee.TabIndex = 20;
            this.btnUpdateEmployee.Text = "Update Employee";
            this.btnUpdateEmployee.UseVisualStyleBackColor = true;
            this.btnUpdateEmployee.Click += new System.EventHandler(this.btnUpdateEmployee_Click);
            // 
            // lblCovidVaccinated
            // 
            this.lblCovidVaccinated.AutoSize = true;
            this.lblCovidVaccinated.Location = new System.Drawing.Point(23, 20);
            this.lblCovidVaccinated.Name = "lblCovidVaccinated";
            this.lblCovidVaccinated.Size = new System.Drawing.Size(126, 20);
            this.lblCovidVaccinated.TabIndex = 22;
            this.lblCovidVaccinated.Text = "Covid Vaccinated:";
            // 
            // rBtnYes
            // 
            this.rBtnYes.AutoSize = true;
            this.rBtnYes.Checked = true;
            this.rBtnYes.Location = new System.Drawing.Point(174, 19);
            this.rBtnYes.Name = "rBtnYes";
            this.rBtnYes.Size = new System.Drawing.Size(51, 24);
            this.rBtnYes.TabIndex = 23;
            this.rBtnYes.TabStop = true;
            this.rBtnYes.Text = "Yes";
            this.rBtnYes.UseVisualStyleBackColor = true;
            // 
            // rBtnNo
            // 
            this.rBtnNo.AutoSize = true;
            this.rBtnNo.Location = new System.Drawing.Point(243, 19);
            this.rBtnNo.Name = "rBtnNo";
            this.rBtnNo.Size = new System.Drawing.Size(50, 24);
            this.rBtnNo.TabIndex = 24;
            this.rBtnNo.Text = "No";
            this.rBtnNo.UseVisualStyleBackColor = true;
            // 
            // lblIsAccountActive
            // 
            this.lblIsAccountActive.AutoSize = true;
            this.lblIsAccountActive.Location = new System.Drawing.Point(20, 16);
            this.lblIsAccountActive.Name = "lblIsAccountActive";
            this.lblIsAccountActive.Size = new System.Drawing.Size(125, 20);
            this.lblIsAccountActive.TabIndex = 25;
            this.lblIsAccountActive.Text = "Is Account Active:";
            // 
            // rBtnActive
            // 
            this.rBtnActive.AutoSize = true;
            this.rBtnActive.Checked = true;
            this.rBtnActive.Location = new System.Drawing.Point(163, 15);
            this.rBtnActive.Name = "rBtnActive";
            this.rBtnActive.Size = new System.Drawing.Size(71, 24);
            this.rBtnActive.TabIndex = 26;
            this.rBtnActive.TabStop = true;
            this.rBtnActive.Text = "Active";
            this.rBtnActive.UseVisualStyleBackColor = true;
            // 
            // rBtnNotActive
            // 
            this.rBtnNotActive.AutoSize = true;
            this.rBtnNotActive.Location = new System.Drawing.Point(252, 15);
            this.rBtnNotActive.Name = "rBtnNotActive";
            this.rBtnNotActive.Size = new System.Drawing.Size(100, 24);
            this.rBtnNotActive.TabIndex = 27;
            this.rBtnNotActive.Text = "Not Active";
            this.rBtnNotActive.UseVisualStyleBackColor = true;
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(30, 292);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(39, 20);
            this.lblAge.TabIndex = 28;
            this.lblAge.Text = "Age:";
            // 
            // tbAge
            // 
            this.tbAge.Location = new System.Drawing.Point(168, 290);
            this.tbAge.Name = "tbAge";
            this.tbAge.Size = new System.Drawing.Size(125, 27);
            this.tbAge.TabIndex = 29;
            // 
            // lblNationality
            // 
            this.lblNationality.AutoSize = true;
            this.lblNationality.Location = new System.Drawing.Point(27, 255);
            this.lblNationality.Name = "lblNationality";
            this.lblNationality.Size = new System.Drawing.Size(85, 20);
            this.lblNationality.TabIndex = 30;
            this.lblNationality.Text = "Nationality:";
            // 
            // cbNationality
            // 
            this.cbNationality.FormattingEnabled = true;
            this.cbNationality.Items.AddRange(new object[] {
            "Bulgarian",
            "Greek",
            "Spanish",
            "Romanian",
            "Serbian",
            "Dutch",
            "German",
            "French",
            "English",
            "Italian"});
            this.cbNationality.Location = new System.Drawing.Point(168, 253);
            this.cbNationality.Name = "cbNationality";
            this.cbNationality.Size = new System.Drawing.Size(151, 28);
            this.cbNationality.TabIndex = 31;
            // 
            // rBtnYesPermanent
            // 
            this.rBtnYesPermanent.AutoSize = true;
            this.rBtnYesPermanent.Checked = true;
            this.rBtnYesPermanent.Location = new System.Drawing.Point(176, 21);
            this.rBtnYesPermanent.Name = "rBtnYesPermanent";
            this.rBtnYesPermanent.Size = new System.Drawing.Size(51, 24);
            this.rBtnYesPermanent.TabIndex = 32;
            this.rBtnYesPermanent.TabStop = true;
            this.rBtnYesPermanent.Text = "Yes";
            this.rBtnYesPermanent.UseVisualStyleBackColor = true;
            // 
            // rBtnNotPermanent
            // 
            this.rBtnNotPermanent.AutoSize = true;
            this.rBtnNotPermanent.Location = new System.Drawing.Point(243, 21);
            this.rBtnNotPermanent.Name = "rBtnNotPermanent";
            this.rBtnNotPermanent.Size = new System.Drawing.Size(50, 24);
            this.rBtnNotPermanent.TabIndex = 33;
            this.rBtnNotPermanent.Text = "No";
            this.rBtnNotPermanent.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 20);
            this.label11.TabIndex = 34;
            this.label11.Text = "Gender:";
            // 
            // rBtnMale
            // 
            this.rBtnMale.AutoSize = true;
            this.rBtnMale.Checked = true;
            this.rBtnMale.Location = new System.Drawing.Point(91, 15);
            this.rBtnMale.Name = "rBtnMale";
            this.rBtnMale.Size = new System.Drawing.Size(63, 24);
            this.rBtnMale.TabIndex = 35;
            this.rBtnMale.TabStop = true;
            this.rBtnMale.Text = "Male";
            this.rBtnMale.UseVisualStyleBackColor = true;
            // 
            // rBtnFemale
            // 
            this.rBtnFemale.AutoSize = true;
            this.rBtnFemale.Location = new System.Drawing.Point(164, 15);
            this.rBtnFemale.Name = "rBtnFemale";
            this.rBtnFemale.Size = new System.Drawing.Size(78, 24);
            this.rBtnFemale.TabIndex = 36;
            this.rBtnFemale.Text = "Female";
            this.rBtnFemale.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rBtnNotActive);
            this.panel1.Controls.Add(this.lblIsAccountActive);
            this.panel1.Controls.Add(this.rBtnActive);
            this.panel1.Location = new System.Drawing.Point(398, 105);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(387, 54);
            this.panel1.TabIndex = 37;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblCovidVaccinated);
            this.panel2.Controls.Add(this.rBtnYes);
            this.panel2.Controls.Add(this.rBtnNo);
            this.panel2.Location = new System.Drawing.Point(398, 169);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(322, 58);
            this.panel2.TabIndex = 38;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.rBtnYesPermanent);
            this.panel3.Controls.Add(this.rBtnNotPermanent);
            this.panel3.Location = new System.Drawing.Point(398, 238);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(316, 65);
            this.panel3.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.rBtnFemale);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.rBtnMale);
            this.panel4.Location = new System.Drawing.Point(398, 37);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(387, 60);
            this.panel4.TabIndex = 39;
            // 
            // createEmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(820, 583);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cbNationality);
            this.Controls.Add(this.lblNationality);
            this.Controls.Add(this.tbAge);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.btnUpdateEmployee);
            this.Controls.Add(this.txbHourlyWage);
            this.Controls.Add(this.txbPhone);
            this.Controls.Add(this.txbAddress);
            this.Controls.Add(this.txbPassword);
            this.Controls.Add(this.txbEmail);
            this.Controls.Add(this.txbLastName);
            this.Controls.Add(this.btnAddEmployee);
            this.Controls.Add(this.cbPosition);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txbFirstName);
            this.Controls.Add(this.txbBsn);
            this.Controls.Add(this.label1);
            this.Name = "createEmployeeForm";
            this.Text = "UpdateEmployeeForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbBsn;
        private System.Windows.Forms.TextBox txbFirstName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ComboBox cbPosition;
        private System.Windows.Forms.Button btnAddEmployee;
        private System.Windows.Forms.TextBox txbLastName;
        private System.Windows.Forms.TextBox txbEmail;
        private System.Windows.Forms.TextBox txbPassword;
        private System.Windows.Forms.TextBox txbAddress;
        private System.Windows.Forms.TextBox txbPhone;
        private System.Windows.Forms.TextBox txbHourlyWage;
        private System.Windows.Forms.Button btnUpdateEmployee;
        private System.Windows.Forms.Label lblCovidVaccinated;
        private System.Windows.Forms.RadioButton rBtnYes;
        private System.Windows.Forms.RadioButton rBtnNo;
        private System.Windows.Forms.Label lblIsAccountActive;
        private System.Windows.Forms.RadioButton rBtnActive;
        private System.Windows.Forms.RadioButton rBtnNotActive;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox tbAge;
        private System.Windows.Forms.Label lblNationality;
        private System.Windows.Forms.ComboBox cbNationality;
        private System.Windows.Forms.RadioButton rBtnYesPermanent;
        private System.Windows.Forms.RadioButton rBtnNotPermanent;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton rBtnMale;
        private System.Windows.Forms.RadioButton rBtnFemale;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
    }
}