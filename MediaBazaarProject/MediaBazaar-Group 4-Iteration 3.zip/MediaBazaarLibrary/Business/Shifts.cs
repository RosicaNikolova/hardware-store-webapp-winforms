﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaBazaarLibrary.Business
{
    public enum Shifts
    {
        MORNING = 1,
        MIDDAY = 2,
        EVENING = 3
    }
}
