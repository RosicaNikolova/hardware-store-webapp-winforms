﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaBazaarLibrary.Business
{
    public class ContractStatistics
    {
        public string ContractType { get; set; }

        public int Count { get; set; }
    }
}
